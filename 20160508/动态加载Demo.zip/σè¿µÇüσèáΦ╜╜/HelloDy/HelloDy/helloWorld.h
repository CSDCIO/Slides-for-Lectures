//
//  helloWorld.h
//  HelloDy
//
//  Created by Tangguo on 16/4/20.
//  Copyright © 2016年 Tangguo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface helloWorld : NSObject


-(NSInteger )helloWorldFunc;

@end
